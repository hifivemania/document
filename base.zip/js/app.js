$(() {
  // hifiveのコントローラ。JavaScriptのオブジェクトとして定義します
  const helloWorldController = {
    // コントローラ名。 __name で定義します。
    __name: 'HelloWorldController',
    // イベント。 "[CSSセレクタ] [イベント]" で呼び出されます
    '#btn click'() {
      alert('hifiveの世界へようこそ！');
    }
  };
  // JavaScriptをhifiveのコントローラ化します
  h5.core.controller('#container', helloWorldController);
});
